

<?php $__env->startSection('content'); ?>
<div class="container">

    <h2>Lista de Artículos</h2>

    <a href="<?php echo e(route('articulos.create')); ?>" class="btn btn-primary mb-3">Nuevo Artículo</a>

    
    <form method="GET" action="<?php echo e(route('articulos.index')); ?>" class="mb-3">
        <div class="input-group">
            <input type="text" name="buscar" class="form-control" placeholder="Buscar por ID o descripción"
                value="<?php echo e($buscar ?? ''); ?>">
            <button class="btn btn-success">Buscar</button>

            <?php if(!empty($buscar)): ?>
                <a href="<?php echo e(route('articulos.index')); ?>" class="btn btn-secondary">Limpiar</a>
            <?php endif; ?>
        </div>
    </form>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID Artículo</th>
                <th>Descripción</th>
                <th>Precio Venta</th>
                <th>Precio Costo</th>
                <th>Stock</th>
                <th>Tipo Artículo</th>
                <th>Proveedor</th>
                <th>Fecha Ingreso</th>
                <th>Acciones</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $art): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($art->id_articulo); ?></td>
                    <td><?php echo e($art->descripcion); ?></td>
                    <td><?php echo e($art->precio_venta); ?></td>
                    <td><?php echo e($art->precio_costo); ?></td>
                    <td><?php echo e($art->stock); ?></td>
                    <td><?php echo e($art->tipoArticulo->descripcion_articulo ?? '---'); ?></td>
                    <td><?php echo e($art->proveedor->Nombre_comercial ?? '---'); ?></td>
                    <td><?php echo e($art->fecha_ingreso); ?></td>

                    <td>
                        <a href="<?php echo e(route('articulos.edit', $art->id_articulo)); ?>" class="btn btn-warning">Editar</a>

                        <form action="<?php echo e(route('articulos.destroy', $art->id_articulo)); ?>"
                              method="POST" style="display:inline-block">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>

    
    <div class="d-flex justify-content-center mt-3">
        <?php echo e($articulos->links('pagination::bootstrap-4')); ?>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\YULISA\Desktop\ProyectoPpd\tienda\resources\views/articulos/index.blade.php ENDPATH**/ ?>