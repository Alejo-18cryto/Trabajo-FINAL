

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Registrar Venta</h2>

    <form action="<?php echo e(route('facturas.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="row">
            <div class="col-md-4">
                <label>N° Factura</label>
                <input type="text" name="Nnm_factura" class="form-control" required>
            </div>

            <div class="col-md-4">
                <label>Cliente</label>
                <select name="cod_cliente" class="form-control" required>
                    <option value="">Seleccione</option>
                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($c->Documento); ?>"><?php echo e($c->Nombres); ?> <?php echo e($c->Apellidos); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-md-4">
                <label>Forma de Pago</label>
                <select name="cod_formapago" class="form-control" required>
                    <?php $__currentLoopData = $formas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($f->id_formapago); ?>"><?php echo e($f->Descripcion_formapago); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <hr>

        <h4>Artículos</h4>

        <table class="table" id="tablaItems">
            <thead>
                <tr>
                    <th>Artículo</th>
                    <th>Precio</th>
                    <th>Stock</th>
                    <th>Cantidad</th>
                    <th></th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>

        <select id="selectArticulo" class="form-control mt-2">
            <option value="">Agregar artículo...</option>
            <?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($a->id_articulo); ?>"
                    data-precio="<?php echo e($a->precio_venta); ?>"
                    data-stock="<?php echo e($a->stock); ?>">
                    <?php echo e($a->descripcion); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <hr>

        <button type="submit" class="btn btn-success">Guardar Venta</button>
    </form>
</div>

<script>
document.getElementById('selectArticulo').addEventListener('change', function() {
    let id = this.value;
    if (!id) return;

    let precio = this.selectedOptions[0].dataset.precio;
    let stock = this.selectedOptions[0].dataset.stock;
    let desc = this.selectedOptions[0].text;

    // Contar cuántas filas hay para generar el índice del arreglo
    let index = document.querySelectorAll("#tablaItems tbody tr").length;

    let fila = `
        <tr>
            <td>${desc}
                <input type="hidden" name="items[${index}][cod_articulo]" value="${id}">
            </td>
            <td>${precio}</td>
            <td>${stock}</td>
            <td>
                <input type="number" class="form-control"
                       name="items[${index}][cantidad]"
                       min="1" max="${stock}" required>
            </td>
            <td><button type="button" class="btn btn-danger btn-sm borrar">X</button></td>
        </tr>
    `;

    document.querySelector("#tablaItems tbody").insertAdjacentHTML('beforeend', fila);

    this.value = "";
});

document.addEventListener("click", function(e){
    if (e.target.classList.contains('borrar')) {
        e.target.closest('tr').remove();
    }
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\YULISA\Desktop\ProyectoPpd\tienda\resources\views/facturas/create.blade.php ENDPATH**/ ?>