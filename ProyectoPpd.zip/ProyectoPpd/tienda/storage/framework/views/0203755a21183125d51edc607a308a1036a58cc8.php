

<?php $__env->startSection('content'); ?>
<div class="container">

    <h2>Lista de Clientes</h2>

    <a href="<?php echo e(route('clientes.create')); ?>" class="btn btn-primary mb-3">Nuevo Cliente</a>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    
    <form method="GET" action="<?php echo e(route('clientes.index')); ?>" class="mb-3">
        <div class="input-group">
            <input type="text" name="buscar" class="form-control"
                placeholder="Buscar por Documento, Nombre o Apellido"
                value="<?php echo e($buscar ?? ''); ?>">
                
            <button class="btn btn-success">Buscar</button>

            <?php if(!empty($buscar)): ?>
                <a href="<?php echo e(route('clientes.index')); ?>" class="btn btn-secondary">Limpiar</a>
            <?php endif; ?>
        </div>
    </form>

    
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Documento</th>
                <th>Tipo Doc</th>
                <th>Nombres</th>
                <th>Apellidos</th>
                <th>Ciudad</th>
                <th>Dirección</th>
                <th>Teléfono</th>
                <th>Acciones</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($cliente->Documento); ?></td>
                    <td><?php echo e($cliente->tipoDocumento->Descripcion ?? '---'); ?></td>
                    <td><?php echo e($cliente->Nombres); ?></td>
                    <td><?php echo e($cliente->Apellidos); ?></td>
                    <td><?php echo e($cliente->ciudad->Nombre_ciudad ?? '---'); ?></td>
                    <td><?php echo e($cliente->Direccion); ?></td>
                    <td><?php echo e($cliente->Telefono); ?></td>

                    <td>
                        <a href="<?php echo e(route('clientes.edit', $cliente->Documento)); ?>" class="btn btn-warning">Editar</a>

                        <form action="<?php echo e(route('clientes.destroy', $cliente->Documento)); ?>" method="POST" style="display:inline-block">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>

    
    <div class="d-flex justify-content-center mt-3">
        <?php echo e($clientes->links('pagination::bootstrap-4')); ?>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\YULISA\Desktop\ProyectoPpd\tienda\resources\views/clientes/index.blade.php ENDPATH**/ ?>