

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Factura N° <?php echo e($factura->Nnm_factura); ?></h2>

    <p><strong>Cliente:</strong> <?php echo e($factura->cliente->Nombres); ?> <?php echo e($factura->cliente->Apellidos); ?></p>
    <p><strong>Fecha:</strong> <?php echo e($factura->Fecha_facturacion); ?></p>
    <p><strong>Forma de pago:</strong> <?php echo e($factura->formaPago->Descripcion_formapago); ?></p>

    <h4>Detalle</h4>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Artículo</th>
                <th>Precio</th>
                <th>Cantidad</th>
                <th>Subtotal</th>
                <th>Acciones</th> 
            </tr>
        </thead>

        <tbody>
        <?php $__currentLoopData = $factura->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($d->articulo->descripcion); ?></td>
                <td>S/. <?php echo e($d->articulo->precio_venta); ?></td>
                <td><?php echo e($d->cantidad); ?></td>
                <td>S/. <?php echo e($d->cantidad * $d->articulo->precio_venta); ?></td>

                <td>
                    <a href="<?php echo e(route('devoluciones.create', ['detalle_id' => $d->id_detalle])); ?>"
                       class="btn btn-warning btn-sm">
                        Registrar Devolución
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <h4>Total: S/. <?php echo e(number_format($factura->total_factura, 2)); ?></h4>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\YULISA\Desktop\ProyectoPpd\tienda\resources\views/facturas/show.blade.php ENDPATH**/ ?>