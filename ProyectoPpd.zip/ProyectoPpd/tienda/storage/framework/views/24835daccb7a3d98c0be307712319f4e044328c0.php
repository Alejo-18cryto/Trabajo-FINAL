

<?php $__env->startSection('content'); ?>
<h2>Registrar Devolución</h2>

<form action="<?php echo e(route('devoluciones.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <input type="hidden" name="cod_detallefactura" value="<?php echo e($detalle->id_detalle); ?>">
    <input type="hidden" name="cod_articulo" value="<?php echo e($detalle->cod_articulo); ?>">

    <div class="mb-3">
        <label>Artículo</label>
        <input type="text" class="form-control" value="<?php echo e($detalle->articulo->descripcion); ?>" readonly>
    </div>

    <div class="mb-3">
        <label>Cantidad comprada</label>
        <input type="number" class="form-control" value="<?php echo e($detalle->cantidad); ?>" readonly>
    </div>

    <div class="mb-3">
        <label>Cantidad a devolver</label>
        <input type="number" name="cantidad" class="form-control" min="1" max="<?php echo e($detalle->cantidad); ?>" required>
    </div>

    <div class="mb-3">
        <label>Motivo</label>
        <textarea name="Motivo" class="form-control" required></textarea>
    </div>

    <button class="btn btn-success">Registrar Devolución</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\YULISA\Desktop\ProyectoPpd\tienda\resources\views/devoluciones/create.blade.php ENDPATH**/ ?>