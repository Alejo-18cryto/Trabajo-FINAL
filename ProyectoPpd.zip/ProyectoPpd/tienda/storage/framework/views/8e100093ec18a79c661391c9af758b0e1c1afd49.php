

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Nueva Forma de Pago</h2>

    <form action="<?php echo e(route('formapago.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label>Descripción</label>
            <input type="text" name="Descripcion_formapago" class="form-control" required>
        </div>

        <button class="btn btn-success">Guardar</button>
        <a href="<?php echo e(route('formapago.index')); ?>" class="btn btn-secondary">Cancelar</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\YULISA\Desktop\ProyectoPpd\tienda\resources\views/formapago/create.blade.php ENDPATH**/ ?>