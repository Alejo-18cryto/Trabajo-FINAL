

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Proveedores</h2>

    <form method="GET" class="mb-3">
        <input type="text" name="buscar" class="form-control" placeholder="Buscar proveedor..." value="<?php echo e($busqueda); ?>">
    </form>

    <a href="<?php echo e(route('proveedores.create')); ?>" class="btn btn-primary mb-3">Nuevo Proveedor</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>Documento</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Nombre Comercial</th>
                <th>Teléfono</th>
                <th>Opciones</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($p->No_documento); ?></td>
                <td><?php echo e($p->Nombre); ?></td>
                <td><?php echo e($p->Apellido); ?></td>
                <td><?php echo e($p->Nombre_comercial); ?></td>
                <td><?php echo e($p->Telefono); ?></td>
                <td>
                    <a href="<?php echo e(route('proveedores.edit', $p->No_documento)); ?>" class="btn btn-warning btn-sm">Editar</a>

                    <form action="<?php echo e(route('proveedores.destroy', $p->No_documento)); ?>" method="POST" style="display:inline">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar proveedor?')">Eliminar</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo e($proveedores->links()); ?>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\YULISA\Desktop\ProyectoPpd\tienda\resources\views/proveedores/index.blade.php ENDPATH**/ ?>