

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Registrar Proveedor</h2>

    <form action="<?php echo e(route('proveedores.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="row">
            <div class="col-md-4">
                <label>Documento</label>
                <input type="text" name="No_documento" class="form-control" required>
            </div>

            <div class="col-md-4">
                <label>Tipo Documento</label>
                <select name="cod_tipo_documento" class="form-control" required>
                    <option value="">Seleccione</option>
                    <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($t->id_tipo_documento); ?>"><?php echo e($t->Descripcion); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-md-4">
                <label>Ciudad</label>
                <select name="cod_ciudad" class="form-control" required>
                    <?php $__currentLoopData = $ciudades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($c->Codigo_ciudad); ?>"><?php echo e($c->Nombre_ciudad); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="row mt-2">
            <div class="col-md-6">
                <label>Nombre</label>
                <input type="text" name="Nombre" class="form-control" required>
            </div>

            <div class="col-md-6">
                <label>Apellido</label>
                <input type="text" name="Apellido" class="form-control" required>
            </div>
        </div>

        <div class="mt-2">
            <label>Nombre Comercial</label>
            <input type="text" name="Nombre_comercial" class="form-control" required>
        </div>

        <div class="mt-2">
            <label>Dirección</label>
            <input type="text" name="Direccion" class="form-control" required>
        </div>

        <div class="mt-2">
            <label>Teléfono</label>
            <input type="text" name="Telefono" class="form-control" required>
        </div>

        <button class="btn btn-success mt-3">Guardar</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\YULISA\Desktop\ProyectoPpd\tienda\resources\views/proveedores/create.blade.php ENDPATH**/ ?>