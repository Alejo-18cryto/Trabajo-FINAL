

<?php $__env->startSection('content'); ?>
<h2>Devoluciones Registradas</h2>

<a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary mb-3">Volver</a>

<table class="table table-bordered">
    <thead class="table-dark">
        <tr>
            <th>Artículo</th>
            <th>Cantidad</th>
            <th>Motivo</th>
            <th>Fecha</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $devoluciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($d->articulo->descripcion); ?></td>
            <td><?php echo e($d->cantidad); ?></td>
            <td><?php echo e($d->Motivo); ?></td>
            <td><?php echo e($d->Fecha_devolucion); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\YULISA\Desktop\ProyectoPpd\tienda\resources\views/devoluciones/index.blade.php ENDPATH**/ ?>