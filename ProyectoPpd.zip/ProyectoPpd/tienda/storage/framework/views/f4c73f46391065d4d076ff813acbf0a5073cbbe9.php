

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Facturas</h2>

    <a href="<?php echo e(route('facturas.create')); ?>" class="btn btn-primary mb-3">
        Nueva Factura
    </a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>N°</th>
                <th>Cliente</th>
                <th>Fecha</th>
                <th>Total</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $facturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($f->Nnm_factura); ?></td>
                <td><?php echo e($f->cliente->Nombres); ?> <?php echo e($f->cliente->Apellidos); ?></td>
                <td><?php echo e($f->Fecha_facturacion); ?></td>
                <td>S/. <?php echo e(number_format($f->total_factura, 2)); ?></td>
                <td>
                    <a href="<?php echo e(route('facturas.show', $f->Nnm_factura)); ?>"
                       class="btn btn-info btn-sm">Ver</a>

                    <form action="<?php echo e(route('facturas.destroy', $f->Nnm_factura)); ?>"
                          method="POST" class="d-inline"
                          onsubmit="return confirm('¿Eliminar factura?')">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger btn-sm">Eliminar</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\YULISA\Desktop\ProyectoPpd\tienda\resources\views/facturas/index.blade.php ENDPATH**/ ?>