<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Facturación</title>

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Sistema</a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="menu">
            <ul class="navbar-nav me-auto">

                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('clientes.*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('clientes.index')); ?>">
                        Clientes
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('articulos.*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('articulos.index')); ?>">
                        Artículos
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('proveedores.*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('proveedores.index')); ?>">
                        Proveedores
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('facturas.*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('facturas.index')); ?>">
                        Facturas
                    </a>
                </li>

                 <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('devoluciones.*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('devoluciones.index')); ?>">
                        devoluciones
                    </a>
                </li>

                 <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('formapago.*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('formapago.index')); ?>">
                        Forma de Pago
                    </a>
                </li>

                 <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('tipoarticulo.*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('tipoarticulo.index')); ?>">
                       Tipo de Articulo
                    </a>
                </li>
            </ul>

        

            <span class="navbar-text text-white">
                <?php if(auth()->guard()->check()): ?>
                    <?php echo e(auth()->user()->name); ?>

                <?php else: ?>
                    Invitado
                <?php endif; ?>
            </span>

        </div>
    </div>
</nav>

<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\Users\YULISA\Desktop\ProyectoPpd\tienda\resources\views/layouts/app.blade.php ENDPATH**/ ?>