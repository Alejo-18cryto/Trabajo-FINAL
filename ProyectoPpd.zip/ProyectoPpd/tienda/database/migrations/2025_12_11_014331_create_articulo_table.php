<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateArticuloTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
{
    Schema::create('articulo', function (Blueprint $table) {
        $table->id('id_articulo');
        $table->string('descripcion', 30);
        $table->integer('precio_venta');
        $table->integer('precio_costo');
        $table->integer('stock');
        $table->unsignedBigInteger('cod_tipo_articulo');
        $table->string('cod_proveedor', 20);
        $table->string('fecha_ingreso', 15);

        $table->foreign('cod_tipo_articulo')->references('id_tipoarticulo')->on('tipo_articulo')->cascadeOnUpdate()->restrictOnDelete();
        $table->foreign('cod_proveedor')->references('No_documento')->on('proveedor')->cascadeOnUpdate()->restrictOnDelete();
    });
}


    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('articulo');
    }
}
