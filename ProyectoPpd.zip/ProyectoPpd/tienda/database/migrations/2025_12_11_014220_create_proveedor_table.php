<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProveedorTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
  public function up()
{
    Schema::create('proveedor', function (Blueprint $table) {
        $table->string('No_documento', 20)->primary();
        $table->unsignedBigInteger('cod_tipo_documento');
        $table->string('Nombre', 20);
        $table->string('Apellido', 20);
        $table->string('Nombre_comercial', 20);
        $table->string('Direccion', 40);
        $table->unsignedBigInteger('cod_ciudad');
        $table->string('Telefono', 15);

        $table->foreign('cod_tipo_documento')->references('id_tipo_documento')->on('tipo_de_documento')->cascadeOnUpdate()->restrictOnDelete();
        $table->foreign('cod_ciudad')->references('Codigo_ciudad')->on('ciudad')->cascadeOnUpdate()->restrictOnDelete();
    });
}


    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('proveedor');
    }
}
