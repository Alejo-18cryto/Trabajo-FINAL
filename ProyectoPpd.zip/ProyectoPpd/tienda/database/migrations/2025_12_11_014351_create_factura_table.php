<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFacturaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
{
    Schema::create('factura', function (Blueprint $table) {
        $table->string('Nnm_factura', 20)->primary();
        $table->string('cod_cliente', 15);
        $table->string('Nombre_empleado', 30);
        $table->string('Fecha_facturacion', 15);
        $table->unsignedBigInteger('cod_formapago');
        $table->decimal('total_factura', 10, 2);
        $table->decimal('IVA', 10, 2);

        $table->foreign('cod_cliente')->references('Documento')->on('cliente')->cascadeOnUpdate()->restrictOnDelete();
        $table->foreign('cod_formapago')->references('id_formapago')->on('forma_de_pago')->cascadeOnUpdate()->restrictOnDelete();
    });
}


    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('factura');
    }
}
