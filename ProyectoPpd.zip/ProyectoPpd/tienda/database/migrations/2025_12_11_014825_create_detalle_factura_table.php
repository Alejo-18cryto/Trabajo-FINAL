<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDetalleFacturaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
public function up()
{
    Schema::create('detalle_factura', function (Blueprint $table) {
        $table->id('id_detalle');

        $table->string('cod_factura', 20)->index();
        $table->unsignedBigInteger('cod_articulo');
        $table->integer('cantidad');

        $table->foreign('cod_factura')->references('Nnm_factura')->on('factura')->cascadeOnUpdate()->cascadeOnDelete();

        $table->foreign('cod_articulo')->references('id_articulo')->on('articulo')->cascadeOnUpdate()->restrictOnDelete();
    });
}



    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('detalle_factura');
    }
}
