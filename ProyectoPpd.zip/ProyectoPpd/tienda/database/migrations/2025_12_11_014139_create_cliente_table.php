<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateClienteTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
   public function up()
{
    Schema::create('cliente', function (Blueprint $table) {
        $table->string('Documento', 15)->primary();
        $table->unsignedBigInteger('cod_tipo_documento');
        $table->string('Nombres', 20);
        $table->string('Apellidos', 20);
        $table->string('Direccion', 40);
        $table->unsignedBigInteger('cod_ciudad');
        $table->string('Telefono', 20);

        $table->foreign('cod_tipo_documento')->references('id_tipo_documento')->on('tipo_de_documento')->cascadeOnUpdate()->restrictOnDelete();
        $table->foreign('cod_ciudad')->references('Codigo_ciudad')->on('ciudad')->cascadeOnUpdate()->restrictOnDelete();
    });
}


    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cliente');
    }
}
