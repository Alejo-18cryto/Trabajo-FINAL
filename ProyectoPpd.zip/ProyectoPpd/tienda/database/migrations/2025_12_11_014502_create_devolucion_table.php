<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDevolucionTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
   public function up()
{
    Schema::create('devolucion', function (Blueprint $table) {
        $table->string('cod_detallefactura', 20);
        $table->unsignedBigInteger('cod_articulo');
        $table->string('Motivo', 15);
        $table->string('Fecha_devolucion', 10);
        $table->integer('cantidad');

        $table->foreign('cod_detallefactura')->references('cod_factura')->on('detalle_factura')->cascadeOnUpdate()->cascadeOnDelete();
        $table->foreign('cod_articulo')->references('id_articulo')->on('articulo')->cascadeOnUpdate()->restrictOnDelete();
    });
}


    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('devolucion');
    }
}
