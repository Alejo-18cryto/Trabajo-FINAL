<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Factura extends Model
{
    use HasFactory;

    public $timestamps = false;
    protected $table = 'factura';
    protected $primaryKey = 'Nnm_factura';
    public $incrementing = false;

    protected $fillable = [
        'Nnm_factura',
        'cod_cliente',
        'Nombre_empleado',
        'Fecha_facturacion',
        'cod_formapago',
        'total_factura',
        'IVA'
    ];

    public function cliente()
    {
        return $this->belongsTo(Cliente::class, 'cod_cliente', 'Documento');
    }

    public function formaPago()
    {
        return $this->belongsTo(FormaPago::class, 'cod_formapago', 'id_formapago');
    }

    public function detalles()
    {
        return $this->hasMany(DetalleFactura::class, 'cod_factura', 'Nnm_factura');
    }

    public function devoluciones()
    {
        return $this->hasMany(Devolucion::class, 'cod_detallefactura', 'Nnm_factura');
    }
}
