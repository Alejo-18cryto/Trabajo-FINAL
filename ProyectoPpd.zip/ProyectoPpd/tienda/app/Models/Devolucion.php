<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Devolucion extends Model
{
    use HasFactory;

    public $timestamps = false;
    protected $table = 'devolucion';
    protected $primaryKey = null;
    public $incrementing = false;

    protected $fillable = [
        'cod_detallefactura',
        'cod_articulo',
        'Motivo',
        'Fecha_devolucion',
        'cantidad'
    ];

    public function detalleFactura()
    {
        return $this->belongsTo(DetalleFactura::class, 'cod_detallefactura', 'id_detalle');
    }

    public function articulo()
    {
        return $this->belongsTo(Articulo::class, 'cod_articulo', 'id_articulo');
    }
}
