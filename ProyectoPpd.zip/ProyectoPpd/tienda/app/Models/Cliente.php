<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cliente extends Model
{
    public $timestamps = false;
    protected $table = 'cliente';
    protected $primaryKey = 'Documento';
    public $incrementing = false;

    protected $fillable = [
        'Documento',
        'cod_tipo_documento',
        'Nombres',
        'Apellidos',
        'Direccion',
        'cod_ciudad',
        'Telefono'
    ];

    public function tipoDocumento()
    {
        return $this->belongsTo(TipoDocumento::class, 'cod_tipo_documento', 'id_tipo_documento');
    }

    public function ciudad()
    {
        return $this->belongsTo(Ciudad::class, 'cod_ciudad', 'Codigo_ciudad');
    }
}

