<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TipoDocumento extends Model
{
    use HasFactory;

    public $timestamps = false;
    protected $table = 'tipo_de_documento';
    protected $primaryKey = 'id_tipo_documento';

    protected $fillable = [
        'id_tipo_documento',
        'Descripcion'
    ];

    public function proveedores()
    {
        return $this->hasMany(Proveedor::class, 'cod_tipo_documento', 'id_tipo_documento');
    }

    public function clientes()
    {
        return $this->hasMany(Cliente::class, 'cod_tipo_documento', 'id_tipo_documento');
    }
}
