<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FormaPago extends Model
{
    use HasFactory;

    public $timestamps = false;
    protected $table = 'forma_de_pago';
    protected $primaryKey = 'id_formapago';

    protected $fillable = [
        'id_formapago',
        'Descripcion_formapago'
    ];

    public function facturas()
    {
        return $this->hasMany(Factura::class, 'cod_formapago', 'id_formapago');
    }
}
