<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TipoArticulo extends Model
{
    use HasFactory;

    public $timestamps = false;
    protected $table = 'tipo_articulo';
    protected $primaryKey = 'id_tipoarticulo';

    protected $fillable = [
        'id_tipoarticulo',
        'descripcion_articulo'
    ];

    public function articulos()
    {
        return $this->hasMany(Articulo::class, 'cod_tipo_articulo', 'id_tipoarticulo');
    }
}
