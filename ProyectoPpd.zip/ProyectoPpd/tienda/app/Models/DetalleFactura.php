<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DetalleFactura extends Model
{
    use HasFactory;

    public $timestamps = false;
    protected $table = 'detalle_factura';
    protected $primaryKey = 'id_detalle';
    public $incrementing = true;

    protected $fillable = [
        'cod_factura',
        'cod_articulo',
        'cantidad'
    ];

    public function factura()
    {
        return $this->belongsTo(Factura::class, 'cod_factura', 'Nnm_factura');
    }

    public function articulo()
    {
        return $this->belongsTo(Articulo::class, 'cod_articulo', 'id_articulo');
    }
}

