<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ciudad extends Model
{
    use HasFactory;

    public $timestamps = false;
    protected $table = 'ciudad';
    protected $primaryKey = 'Codigo_ciudad';

    protected $fillable = [
        'Codigo_ciudad',
        'Nombre_ciudad'
    ];

    public function proveedores()
    {
        return $this->hasMany(Proveedor::class, 'cod_ciudad', 'Codigo_ciudad');
    }

    public function clientes()
    {
        return $this->hasMany(Cliente::class, 'cod_ciudad', 'Codigo_ciudad');
    }
}
