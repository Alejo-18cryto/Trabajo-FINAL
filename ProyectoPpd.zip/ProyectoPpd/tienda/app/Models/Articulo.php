<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Articulo extends Model
{
    use HasFactory;

    public $timestamps = false;
    protected $table = 'articulo';
    protected $primaryKey = 'id_articulo';

    protected $fillable = [
        'id_articulo',
        'descripcion',
        'precio_venta',
        'precio_costo',
        'stock',
        'cod_tipo_articulo',
        'cod_proveedor',
        'fecha_ingreso'
    ];

    public function tipoArticulo()
    {
        return $this->belongsTo(TipoArticulo::class, 'cod_tipo_articulo', 'id_tipoarticulo');
    }

    public function proveedor()
    {
        return $this->belongsTo(Proveedor::class, 'cod_proveedor', 'No_documento');
    }

    public function detalles()
    {
        return $this->hasMany(DetalleFactura::class, 'cod_articulo', 'id_articulo');
    }

    public function devoluciones()
    {
        return $this->hasMany(Devolucion::class, 'cod_articulo', 'id_articulo');
    }
}
