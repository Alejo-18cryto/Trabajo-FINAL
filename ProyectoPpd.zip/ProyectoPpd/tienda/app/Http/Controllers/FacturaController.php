<?php

namespace App\Http\Controllers;

use App\Models\Factura;
use App\Models\Cliente;
use App\Models\Articulo;
use App\Models\FormaPago;
use App\Models\DetalleFactura;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class FacturaController extends Controller
{
    public function index()
    {
        $facturas = Factura::with('cliente')->orderBy('Fecha_facturacion', 'desc')->get();
        return view('facturas.index', compact('facturas'));
    }

    public function create()
    {
        return view('facturas.create', [
            'clientes' => Cliente::all(),
            'formas'   => FormaPago::all(),
            'articulos' => Articulo::where('stock', '>', 0)->get()
        ]);
    }

    public function store(Request $request)
{
    // Validación mínima
    $request->validate([
        'Nnm_factura' => 'required',
        'cod_cliente' => 'required',
        'cod_formapago' => 'required',
        'items' => 'required|array',
    ]);

    // Calcular total
    $total = 0;

    foreach ($request->items as $item) {
        $articulo = Articulo::find($item['cod_articulo']);
        $total += $articulo->precio_venta * $item['cantidad'];
    }

    $iva = $total * 0.18; // 18% por ejemplo

    // Crear factura
    $factura = Factura::create([
        'Nnm_factura' => $request->Nnm_factura,
        'cod_cliente' => $request->cod_cliente,
        'Nombre_empleado' => auth()->user()->name ?? 'Empleado',
        'Fecha_facturacion' => now()->format('Y-m-d'),
        'cod_formapago' => $request->cod_formapago,
        'total_factura' => $total,
        'IVA' => $iva
    ]);

    // Crear detalles
    foreach ($request->items as $item) {
        DetalleFactura::create([
            'cod_factura' => $factura->Nnm_factura,
            'cod_articulo' => $item['cod_articulo'],
            'cantidad' => $item['cantidad']
        ]);

        // Reducir stock
        $art = Articulo::find($item['cod_articulo']);
        $art->stock -= $item['cantidad'];
        $art->save();
    }

    return redirect()->route('facturas.index')->with('success', 'Factura registrada correctamente');
}

    public function show($id)
    {
        $factura = Factura::with(['cliente', 'formaPago', 'detalles.articulo'])
                          ->findOrFail($id);

        return view('facturas.show', compact('factura'));
    }

    public function destroy($id)
    {
        DB::beginTransaction();

        try {
            $factura = Factura::with('detalles')->findOrFail($id);

            // Restaurar stock
            foreach ($factura->detalles as $detalle) {
                $art = Articulo::find($detalle->cod_articulo);
                $art->stock += $detalle->cantidad;
                $art->save();
            }

            // Eliminar factura + detalles
            $factura->delete();

            DB::commit();

            return back()->with('success', 'Factura eliminada y stock recuperado');

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Error: ' . $e->getMessage());
        }
    }
}
