<?php

namespace App\Http\Controllers;

use App\Models\TipoArticulo;
use Illuminate\Http\Request;

class TipoArticuloController extends Controller
{
    public function index()
    {
        $tipos = TipoArticulo::all();
        return view('tipoarticulo.index', compact('tipos'));
    }

    public function create()
    {
        return view('tipoarticulo.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'descripcion_articulo' => 'required|string|max:255'
        ]);

        TipoArticulo::create([
            'descripcion_articulo' => $request->descripcion_articulo
        ]);

        return redirect()->route('tipoarticulo.index')->with('success', 'Tipo de artículo registrado correctamente.');
    }

    public function edit($id)
    {
        $tipo = TipoArticulo::findOrFail($id);
        return view('tipoarticulo.edit', compact('tipo'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'descripcion_articulo' => 'required|string|max:255'
        ]);

        $tipo = TipoArticulo::findOrFail($id);
        $tipo->update([
            'descripcion_articulo' => $request->descripcion_articulo
        ]);

        return redirect()->route('tipoarticulo.index')->with('success', 'Tipo de artículo actualizado correctamente.');
    }

    public function destroy($id)
    {
        $tipo = TipoArticulo::findOrFail($id);
        $tipo->delete();

        return redirect()->route('tipoarticulo.index')->with('success', 'Tipo de artículo eliminado.');
    }
}
