<?php

namespace App\Http\Controllers;

use App\Models\Proveedor;
use App\Models\TipoDocumento;
use App\Models\Ciudad;
use Illuminate\Http\Request;

class ProveedorController extends Controller
{
    public function index(Request $request)
    {
        $busqueda = $request->input('buscar');

        $proveedores = Proveedor::when($busqueda, function ($q) use ($busqueda) {
                $q->where('Nombre', 'like', "%$busqueda%")
                  ->orWhere('Apellido', 'like', "%$busqueda%")
                  ->orWhere('Nombre_comercial', 'like', "%$busqueda%")
                  ->orWhere('No_documento', 'like', "%$busqueda%");
            })
            ->orderBy('Nombre')
            ->paginate(10);

        return view('proveedores.index', compact('proveedores', 'busqueda'));
    }

    public function create()
    {
        $tipos = TipoDocumento::all();
        $ciudades = Ciudad::all();

        return view('proveedores.create', compact('tipos', 'ciudades'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'No_documento' => 'required',
            'cod_tipo_documento' => 'required',
            'Nombre' => 'required',
            'Apellido' => 'required',
            'Nombre_comercial' => 'required',
            'Direccion' => 'required',
            'cod_ciudad' => 'required',
            'Telefono' => 'required',
        ]);

        Proveedor::create($request->all());

        return redirect()->route('proveedores.index')->with('success', 'Proveedor registrado correctamente.');
    }

    public function edit(Proveedor $proveedore)
    {
        $tipos = TipoDocumento::all();
        $ciudades = Ciudad::all();

        return view('proveedores.edit', compact('proveedore', 'tipos', 'ciudades'));
    }

    public function update(Request $request, Proveedor $proveedore)
    {
        $request->validate([
            'cod_tipo_documento' => 'required',
            'Nombre' => 'required',
            'Apellido' => 'required',
            'Nombre_comercial' => 'required',
            'Direccion' => 'required',
            'cod_ciudad' => 'required',
            'Telefono' => 'required',
        ]);

        $proveedore->update($request->all());

        return redirect()->route('proveedores.index')->with('success', 'Proveedor actualizado correctamente.');
    }

    public function destroy(Proveedor $proveedore)
    {
        $proveedore->delete();

        return redirect()->route('proveedores.index')->with('success', 'Proveedor eliminado.');
    }
}
