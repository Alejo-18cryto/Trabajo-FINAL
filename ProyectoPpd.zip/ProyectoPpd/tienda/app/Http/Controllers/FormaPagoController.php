<?php

namespace App\Http\Controllers;

use App\Models\FormaPago;
use Illuminate\Http\Request;

class FormaPagoController extends Controller
{
    public function index()
    {
        $formas = FormaPago::all();
        return view('formapago.index', compact('formas'));
    }

    public function create()
    {
        return view('formapago.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'Descripcion_formapago' => 'required|string|max:255'
        ]);

        FormaPago::create([
            'Descripcion_formapago' => $request->Descripcion_formapago
        ]);

        return redirect()->route('formapago.index')->with('success', 'Forma de pago registrada correctamente.');
    }

    public function edit($id)
    {
        $forma = FormaPago::findOrFail($id);
        return view('formapago.edit', compact('forma'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'Descripcion_formapago' => 'required|string|max:255'
        ]);

        $forma = FormaPago::findOrFail($id);
        $forma->update([
            'Descripcion_formapago' => $request->Descripcion_formapago
        ]);

        return redirect()->route('formapago.index')->with('success', 'Forma de pago actualizada correctamente.');
    }

    public function destroy($id)
    {
        $forma = FormaPago::findOrFail($id);
        $forma->delete();

        return redirect()->route('formapago.index')->with('success', 'Forma de pago eliminada.');
    }
}
