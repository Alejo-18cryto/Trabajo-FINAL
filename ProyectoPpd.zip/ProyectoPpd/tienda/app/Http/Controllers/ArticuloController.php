<?php

namespace App\Http\Controllers;

use App\Models\Articulo;
use App\Models\TipoArticulo;
use App\Models\Proveedor;
use Illuminate\Http\Request;

class ArticuloController extends Controller
{
    public function index(Request $request)
    {
        $buscar = $request->input('buscar');

        $articulos = Articulo::query()
            ->when($buscar, function($query, $buscar) {
                $query->where('descripcion', 'LIKE', "%$buscar%")
                      ->orWhere('id_articulo', 'LIKE', "%$buscar%");
            })
            ->with(['tipoArticulo','proveedor'])
            ->paginate(10)
            ->appends(['buscar' => $buscar]);

        return view('articulos.index', compact('articulos', 'buscar'));
    }

    public function create()
    {
        $tipoArticulos = TipoArticulo::all();
        $proveedores = Proveedor::all();

        return view('articulos.create', compact('tipoArticulos', 'proveedores'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'descripcion' => 'required',
            'precio_venta' => 'required|numeric',
            'precio_costo' => 'required|numeric',
            'stock' => 'required|integer',
            'cod_tipo_articulo' => 'required',
            'cod_proveedor' => 'required',
            'fecha_ingreso' => 'required'
        ]);

        Articulo::create($request->all());

        return redirect()->route('articulos.index')->with('success', 'Artículo registrado correctamente');
    }

    public function edit($id)
    {
        $articulo = Articulo::findOrFail($id);
        $tipoArticulos = TipoArticulo::all();
        $proveedores = Proveedor::all();

        return view('articulos.edit', compact('articulo', 'tipoArticulos', 'proveedores'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'descripcion' => 'required',
            'precio_venta' => 'required|numeric',
            'precio_costo' => 'required|numeric',
            'stock' => 'required|integer',
            'cod_tipo_articulo' => 'required',
            'cod_proveedor' => 'required',
            'fecha_ingreso' => 'required'
        ]);

        $articulo = Articulo::findOrFail($id);
        $articulo->update($request->all());

        return redirect()->route('articulos.index')->with('success', 'Artículo actualizado correctamente');
    }

    public function destroy($id)
    {
        Articulo::destroy($id);
        return redirect()->route('articulos.index')->with('success', 'Artículo eliminado correctamente');
    }
}
