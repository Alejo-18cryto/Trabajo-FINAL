<?php

namespace App\Http\Controllers;

use App\Models\Cliente;
use App\Models\TipoDocumento;
use App\Models\Ciudad;
use Illuminate\Http\Request;

class ClienteController extends Controller
{
    // LISTAR CLIENTES
public function index(Request $request)
{
    $buscar = $request->input('buscar');

    $clientes = Cliente::query()
        ->when($buscar, function ($query, $buscar) {
            $query->where('Documento', 'LIKE', "%$buscar%")
                  ->orWhere('Nombres', 'LIKE', "%$buscar%")
                  ->orWhere('Apellidos', 'LIKE', "%$buscar%");
        })
        ->with(['tipoDocumento', 'ciudad'])
        ->paginate(10)   // 👈 10 clientes por página
        ->appends(['buscar' => $buscar]); // 👈 mantiene el texto en la paginación

    return view('clientes.index', compact('clientes', 'buscar'));
}

    // FORMULARIO CREAR
    public function create()
    {
        $tiposDocumento = TipoDocumento::all();
        $ciudades = Ciudad::all();
        return view('clientes.create', compact('tiposDocumento', 'ciudades'));
    }

    // GUARDAR CLIENTE
    public function store(Request $request)
    {
        $request->validate([
            'Documento' => 'required|unique:cliente,Documento',
            'cod_tipo_documento' => 'required',
            'Nombres' => 'required',
            'Apellidos' => 'required',
            'Direccion' => 'required',
            'cod_ciudad' => 'required',
            'Telefono' => 'required'
        ]);

        Cliente::create($request->all());

        return redirect()->route('clientes.index')->with('success', 'Cliente registrado correctamente');
    }

    // FORMULARIO EDITAR
    public function edit($Documento)
    {
        $cliente = Cliente::findOrFail($Documento);
        $tiposDocumento = TipoDocumento::all();
        $ciudades = Ciudad::all();

        return view('clientes.edit', compact('cliente', 'tiposDocumento', 'ciudades'));
    }

    // ACTUALIZAR CLIENTE
    public function update(Request $request, $Documento)
    {
        $request->validate([
            'cod_tipo_documento' => 'required',
            'Nombres' => 'required',
            'Apellidos' => 'required',
            'Direccion' => 'required',
            'cod_ciudad' => 'required',
            'Telefono' => 'required'
        ]);

        $cliente = Cliente::findOrFail($Documento);
        $cliente->update($request->all());

        return redirect()->route('clientes.index')->with('success', 'Cliente actualizado');
    }

    // ELIMINAR CLIENTE
    public function destroy($Documento)
    {
        Cliente::destroy($Documento);
        return redirect()->route('clientes.index')->with('success', 'Cliente eliminado');
    }
}
