<?php

namespace App\Http\Controllers;

use App\Models\Devolucion;
use App\Models\DetalleFactura;
use App\Models\Articulo;
use Illuminate\Http\Request;

class DevolucionController extends Controller
{
    public function index()
    {
        $devoluciones = Devolucion::with(['detalleFactura', 'articulo'])->get();
        return view('devoluciones.index', compact('devoluciones'));
    }

    public function create(Request $request)
    {
        // ID del detalle que viene desde la factura
        $detalle = DetalleFactura::with('articulo')->findOrFail($request->detalle_id);

        return view('devoluciones.create', compact('detalle'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'cod_detallefactura' => 'required',
            'cod_articulo' => 'required',
            'cantidad' => 'required|integer|min:1',
            'Motivo' => 'required|max:255',
        ]);

        $detalle = DetalleFactura::findOrFail($request->cod_detallefactura);

        // Evitar devolver más de lo comprado
        if ($request->cantidad > $detalle->cantidad) {
            return back()->withErrors(['cantidad' => 'No puede devolver más de lo comprado.']);
        }

        // Registrar devolución
        Devolucion::create([
            'cod_detallefactura' => $request->cod_detallefactura,
            'cod_articulo' => $request->cod_articulo,
            'Motivo' => $request->Motivo,
            'Fecha_devolucion' => now(),
            'cantidad' => $request->cantidad,
        ]);

        // Aumentar stock
        $art = Articulo::find($request->cod_articulo);
        $art->stock += $request->cantidad;
        $art->save();

        return redirect()->route('devoluciones.index')
            ->with('success', 'Devolución registrada correctamente');
    }
}
