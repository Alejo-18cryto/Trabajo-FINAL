<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ClienteController;
use App\Http\Controllers\ArticuloController;
use App\Http\Controllers\FacturaController;
use App\Http\Controllers\ProveedorController;
use App\Http\Controllers\DevolucionController;
use App\Http\Controllers\FormaPagoController;
use App\Http\Controllers\TipoArticuloController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::resource('clientes', ClienteController::class);

Route::resource('articulos', ArticuloController::class);
Route::resource('facturas', FacturaController::class);
Route::resource('proveedores', ProveedorController::class);
Route::resource('devoluciones', DevolucionController::class);
Route::resource('formapago', FormaPagoController::class);
Route::resource('tipoarticulo', TipoArticuloController::class);




