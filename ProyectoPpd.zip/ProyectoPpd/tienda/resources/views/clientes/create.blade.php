@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Registrar Cliente</h2>

    <form action="{{ route('clientes.store') }}" method="POST">
        @csrf

        <div class="mb-3">
            <label>Documento</label>
            <input type="text" name="Documento" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Tipo Documento</label>
            <select name="cod_tipo_documento" class="form-control" required>
                <option value="">Seleccione</option>
                @foreach($tiposDocumento as $tipo)
                    <option value="{{ $tipo->id_tipo_documento }}">{{ $tipo->Descripcion }}</option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label>Nombres</label>
            <input type="text" name="Nombres" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Apellidos</label>
            <input type="text" name="Apellidos" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Dirección</label>
            <input type="text" name="Direccion" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Ciudad</label>
            <select name="cod_ciudad" class="form-control" required>
                <option value="">Seleccione</option>
                @foreach($ciudades as $c)
                    <option value="{{ $c->Codigo_ciudad }}">{{ $c->Nombre_ciudad }}</option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label>Teléfono</label>
            <input type="text" name="Telefono" class="form-control" required>
        </div>

        <button class="btn btn-success">Guardar</button>
        <a href="{{ route('clientes.index') }}" class="btn btn-secondary">Volver</a>
    </form>
</div>
@endsection
