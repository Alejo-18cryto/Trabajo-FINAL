@extends('layouts.app')

@section('content')
<div class="container">

    <h2>Lista de Clientes</h2>

    <a href="{{ route('clientes.create') }}" class="btn btn-primary mb-3">Nuevo Cliente</a>

    {{-- MENSAJE --}}
    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    {{-- BUSCADOR --}}
    <form method="GET" action="{{ route('clientes.index') }}" class="mb-3">
        <div class="input-group">
            <input type="text" name="buscar" class="form-control"
                placeholder="Buscar por Documento, Nombre o Apellido"
                value="{{ $buscar ?? '' }}">
                
            <button class="btn btn-success">Buscar</button>

            @if(!empty($buscar))
                <a href="{{ route('clientes.index') }}" class="btn btn-secondary">Limpiar</a>
            @endif
        </div>
    </form>

    {{-- TABLA --}}
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Documento</th>
                <th>Tipo Doc</th>
                <th>Nombres</th>
                <th>Apellidos</th>
                <th>Ciudad</th>
                <th>Dirección</th>
                <th>Teléfono</th>
                <th>Acciones</th>
            </tr>
        </thead>

        <tbody>
            @foreach($clientes as $cliente)
                <tr>
                    <td>{{ $cliente->Documento }}</td>
                    <td>{{ $cliente->tipoDocumento->Descripcion ?? '---' }}</td>
                    <td>{{ $cliente->Nombres }}</td>
                    <td>{{ $cliente->Apellidos }}</td>
                    <td>{{ $cliente->ciudad->Nombre_ciudad ?? '---' }}</td>
                    <td>{{ $cliente->Direccion }}</td>
                    <td>{{ $cliente->Telefono }}</td>

                    <td>
                        <a href="{{ route('clientes.edit', $cliente->Documento) }}" class="btn btn-warning">Editar</a>

                        <form action="{{ route('clientes.destroy', $cliente->Documento) }}" method="POST" style="display:inline-block">
                            @csrf
                            @method('DELETE')
                            <button class="btn btn-danger">Eliminar</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>

    </table>

    {{-- PAGINACIÓN --}}
    <div class="d-flex justify-content-center mt-3">
        {{ $clientes->links('pagination::bootstrap-4') }}
    </div>

</div>
@endsection
