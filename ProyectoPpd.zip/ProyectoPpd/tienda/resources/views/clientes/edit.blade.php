@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Editar Cliente</h2>

    <form action="{{ route('clientes.update', $cliente->Documento) }}" method="POST">
        @csrf
        @method('PUT')

        <div class="mb-3">
            <label>Documento</label>
            <input type="text" class="form-control" value="{{ $cliente->Documento }}" disabled>
        </div>

        <div class="mb-3">
            <label>Tipo Documento</label>
            <select name="cod_tipo_documento" class="form-control" required>
                @foreach($tiposDocumento as $tipo)
                    <option value="{{ $tipo->id_tipo_documento }}"
                        @if($tipo->id_tipo_documento == $cliente->cod_tipo_documento) selected @endif>
                        {{ $tipo->Descripcion }}
                    </option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label>Nombres</label>
            <input type="text" name="Nombres" class="form-control" value="{{ $cliente->Nombres }}" required>
        </div>

        <div class="mb-3">
            <label>Apellidos</label>
            <input type="text" name="Apellidos" class="form-control" value="{{ $cliente->Apellidos }}" required>
        </div>

        <div class="mb-3">
            <label>Dirección</label>
            <input type="text" name="Direccion" class="form-control" value="{{ $cliente->Direccion }}" required>
        </div>

        <div class="mb-3">
            <label>Ciudad</label>
            <select name="cod_ciudad" class="form-control" required>
                @foreach($ciudades as $c)
                    <option value="{{ $c->Codigo_ciudad }}"
                        @if($c->Codigo_ciudad == $cliente->cod_ciudad) selected @endif>
                        {{ $c->Nombre_ciudad }}
                    </option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label>Teléfono</label>
            <input type="text" name="Telefono" class="form-control" value="{{ $cliente->Telefono }}" required>
        </div>

        <button class="btn btn-primary">Actualizar</button>
        <a href="{{ route('clientes.index') }}" class="btn btn-secondary">Volver</a>
    </form>
</div>
@endsection
