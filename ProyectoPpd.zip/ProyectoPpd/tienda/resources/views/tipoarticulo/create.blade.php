@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Nuevo Tipo de Artículo</h2>

    <form action="{{ route('tipoarticulo.store') }}" method="POST">
        @csrf

        <div class="mb-3">
            <label>Descripción</label>
            <input type="text" name="descripcion_articulo" class="form-control" required>
        </div>

        <button class="btn btn-success">Guardar</button>
        <a href="{{ route('tipoarticulo.index') }}" class="btn btn-secondary">Cancelar</a>
    </form>
</div>
@endsection
