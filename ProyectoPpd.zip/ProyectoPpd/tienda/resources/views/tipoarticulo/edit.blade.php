@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Editar Tipo de Artículo</h2>

    <form action="{{ route('tipoarticulo.update', $tipo->id_tipoarticulo) }}" method="POST">
        @csrf
        @method('PUT')

        <div class="mb-3">
            <label>Descripción</label>
            <input type="text" 
                   name="descripcion_articulo" 
                   value="{{ $tipo->descripcion_articulo }}" 
                   class="form-control" 
                   required>
        </div>

        <button class="btn btn-success">Actualizar</button>
        <a href="{{ route('tipoarticulo.index') }}" class="btn btn-secondary">Cancelar</a>
    </form>
</div>
@endsection
