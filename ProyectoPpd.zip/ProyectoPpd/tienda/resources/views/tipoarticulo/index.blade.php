@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Tipos de Artículo</h2>

    <a href="{{ route('tipoarticulo.create') }}" class="btn btn-primary mb-3">
        Nuevo Tipo de Artículo
    </a>

    @if(session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Descripción</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
        @foreach($tipos as $t)
            <tr>
                <td>{{ $t->id_tipoarticulo }}</td>
                <td>{{ $t->descripcion_articulo }}</td>
                <td>
                    <a href="{{ route('tipoarticulo.edit', $t->id_tipoarticulo) }}" class="btn btn-warning btn-sm">Editar</a>

                    <form action="{{ route('tipoarticulo.destroy', $t->id_tipoarticulo) }}" method="POST" style="display:inline-block;">
                        @csrf
                        @method('DELETE')

                        <button class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar este tipo?')">
                            Eliminar
                        </button>
                    </form>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
@endsection
