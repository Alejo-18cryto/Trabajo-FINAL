@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Registrar Venta</h2>

    <form action="{{ route('facturas.store') }}" method="POST">
        @csrf

        <div class="row">
            <div class="col-md-4">
                <label>N° Factura</label>
                <input type="text" name="Nnm_factura" class="form-control" required>
            </div>

            <div class="col-md-4">
                <label>Cliente</label>
                <select name="cod_cliente" class="form-control" required>
                    <option value="">Seleccione</option>
                    @foreach($clientes as $c)
                        <option value="{{ $c->Documento }}">{{ $c->Nombres }} {{ $c->Apellidos }}</option>
                    @endforeach
                </select>
            </div>

            <div class="col-md-4">
                <label>Forma de Pago</label>
                <select name="cod_formapago" class="form-control" required>
                    @foreach($formas as $f)
                        <option value="{{ $f->id_formapago }}">{{ $f->Descripcion_formapago }}</option>
                    @endforeach
                </select>
            </div>
        </div>

        <hr>

        <h4>Artículos</h4>

        <table class="table" id="tablaItems">
            <thead>
                <tr>
                    <th>Artículo</th>
                    <th>Precio</th>
                    <th>Stock</th>
                    <th>Cantidad</th>
                    <th></th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>

        <select id="selectArticulo" class="form-control mt-2">
            <option value="">Agregar artículo...</option>
            @foreach($articulos as $a)
                <option value="{{ $a->id_articulo }}"
                    data-precio="{{ $a->precio_venta }}"
                    data-stock="{{ $a->stock }}">
                    {{ $a->descripcion }}
                </option>
            @endforeach
        </select>

        <hr>

        <button type="submit" class="btn btn-success">Guardar Venta</button>
    </form>
</div>

<script>
document.getElementById('selectArticulo').addEventListener('change', function() {
    let id = this.value;
    if (!id) return;

    let precio = this.selectedOptions[0].dataset.precio;
    let stock = this.selectedOptions[0].dataset.stock;
    let desc = this.selectedOptions[0].text;

    // Contar cuántas filas hay para generar el índice del arreglo
    let index = document.querySelectorAll("#tablaItems tbody tr").length;

    let fila = `
        <tr>
            <td>${desc}
                <input type="hidden" name="items[${index}][cod_articulo]" value="${id}">
            </td>
            <td>${precio}</td>
            <td>${stock}</td>
            <td>
                <input type="number" class="form-control"
                       name="items[${index}][cantidad]"
                       min="1" max="${stock}" required>
            </td>
            <td><button type="button" class="btn btn-danger btn-sm borrar">X</button></td>
        </tr>
    `;

    document.querySelector("#tablaItems tbody").insertAdjacentHTML('beforeend', fila);

    this.value = "";
});

document.addEventListener("click", function(e){
    if (e.target.classList.contains('borrar')) {
        e.target.closest('tr').remove();
    }
});
</script>

@endsection
