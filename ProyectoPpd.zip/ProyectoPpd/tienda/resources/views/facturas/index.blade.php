@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Facturas</h2>

    <a href="{{ route('facturas.create') }}" class="btn btn-primary mb-3">
        Nueva Factura
    </a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>N°</th>
                <th>Cliente</th>
                <th>Fecha</th>
                <th>Total</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            @foreach($facturas as $f)
            <tr>
                <td>{{ $f->Nnm_factura }}</td>
                <td>{{ $f->cliente->Nombres }} {{ $f->cliente->Apellidos }}</td>
                <td>{{ $f->Fecha_facturacion }}</td>
                <td>S/. {{ number_format($f->total_factura, 2) }}</td>
                <td>
                    <a href="{{ route('facturas.show', $f->Nnm_factura) }}"
                       class="btn btn-info btn-sm">Ver</a>

                    <form action="{{ route('facturas.destroy', $f->Nnm_factura) }}"
                          method="POST" class="d-inline"
                          onsubmit="return confirm('¿Eliminar factura?')">
                        @csrf @method('DELETE')
                        <button class="btn btn-danger btn-sm">Eliminar</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
