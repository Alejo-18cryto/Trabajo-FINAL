@extends('layouts.app')

@section('content')
<div class="container">

    <h2>Registrar Nuevo Artículo</h2>

    <a href="{{ route('articulos.index') }}" class="btn btn-secondary mb-3">Volver</a>

    <form action="{{ route('articulos.store') }}" method="POST">
        @csrf

        <div class="mb-3">
            <label class="form-label">Descripción:</label>
            <input type="text" name="descripcion"
                   class="form-control @error('descripcion') is-invalid @enderror"
                   value="{{ old('descripcion') }}">
            @error('descripcion')
                <span class="invalid-feedback">{{ $message }}</span>
            @enderror
        </div>

        <div class="mb-3">
            <label class="form-label">Precio de Venta:</label>
            <input type="number" name="precio_venta"
                   class="form-control @error('precio_venta') is-invalid @enderror"
                   value="{{ old('precio_venta') }}">
            @error('precio_venta')
                <span class="invalid-feedback">{{ $message }}</span>
            @enderror
        </div>

        <div class="mb-3">
            <label class="form-label">Precio de Costo:</label>
            <input type="number" name="precio_costo"
                   class="form-control @error('precio_costo') is-invalid @enderror"
                   value="{{ old('precio_costo') }}">
            @error('precio_costo')
                <span class="invalid-feedback">{{ $message }}</span>
            @enderror
        </div>

        <div class="mb-3">
            <label class="form-label">Stock:</label>
            <input type="number" name="stock"
                   class="form-control @error('stock') is-invalid @enderror"
                   value="{{ old('stock') }}">
            @error('stock')
                <span class="invalid-feedback">{{ $message }}</span>
            @enderror
        </div>

        <div class="mb-3">
            <label class="form-label">Tipo de Artículo:</label>
            <select name="cod_tipo_articulo"
                class="form-select @error('cod_tipo_articulo') is-invalid @enderror">
                <option value="">Seleccione...</option>
                @foreach($tipoArticulos as $tipo)
                    <option value="{{ $tipo->id_tipoarticulo }}"
                        {{ old('cod_tipo_articulo') == $tipo->id_tipoarticulo ? 'selected' : '' }}>
                        {{ $tipo->descripcion_articulo }}
                    </option>
                @endforeach
            </select>
            @error('cod_tipo_articulo')
                <span class="invalid-feedback">{{ $message }}</span>
            @enderror
        </div>

        <div class="mb-3">
            <label class="form-label">Proveedor:</label>
            <select name="cod_proveedor"
                class="form-select @error('cod_proveedor') is-invalid @enderror">
                <option value="">Seleccione...</option>
                @foreach($proveedores as $prov)
                    <option value="{{ $prov->No_documento }}"
                        {{ old('cod_proveedor') == $prov->No_documento ? 'selected' : '' }}>
                        {{ $prov->Nombre_comercial }}
                    </option>
                @endforeach
            </select>
            @error('cod_proveedor')
                <span class="invalid-feedback">{{ $message }}</span>
            @enderror
        </div>

        <div class="mb-3">
            <label class="form-label">Fecha de ingreso:</label>
            <input type="date" name="fecha_ingreso"
                   class="form-control @error('fecha_ingreso') is-invalid @enderror"
                   value="{{ old('fecha_ingreso') }}">
            @error('fecha_ingreso')
                <span class="invalid-feedback">{{ $message }}</span>
            @enderror
        </div>

        <button class="btn btn-primary">Guardar</button>
    </form>
</div>
@endsection
