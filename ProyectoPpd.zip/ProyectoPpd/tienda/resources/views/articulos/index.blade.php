@extends('layouts.app')

@section('content')
<div class="container">

    <h2>Lista de Artículos</h2>

    <a href="{{ route('articulos.create') }}" class="btn btn-primary mb-3">Nuevo Artículo</a>

    {{-- Buscador --}}
    <form method="GET" action="{{ route('articulos.index') }}" class="mb-3">
        <div class="input-group">
            <input type="text" name="buscar" class="form-control" placeholder="Buscar por ID o descripción"
                value="{{ $buscar ?? '' }}">
            <button class="btn btn-success">Buscar</button>

            @if(!empty($buscar))
                <a href="{{ route('articulos.index') }}" class="btn btn-secondary">Limpiar</a>
            @endif
        </div>
    </form>

    {{-- Mensajes --}}
    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    {{-- Tabla --}}
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID Artículo</th>
                <th>Descripción</th>
                <th>Precio Venta</th>
                <th>Precio Costo</th>
                <th>Stock</th>
                <th>Tipo Artículo</th>
                <th>Proveedor</th>
                <th>Fecha Ingreso</th>
                <th>Acciones</th>
            </tr>
        </thead>

        <tbody>
            @foreach($articulos as $art)
                <tr>
                    <td>{{ $art->id_articulo }}</td>
                    <td>{{ $art->descripcion }}</td>
                    <td>{{ $art->precio_venta }}</td>
                    <td>{{ $art->precio_costo }}</td>
                    <td>{{ $art->stock }}</td>
                    <td>{{ $art->tipoArticulo->descripcion_articulo ?? '---' }}</td>
                    <td>{{ $art->proveedor->Nombre_comercial ?? '---' }}</td>
                    <td>{{ $art->fecha_ingreso }}</td>

                    <td>
                        <a href="{{ route('articulos.edit', $art->id_articulo) }}" class="btn btn-warning">Editar</a>

                        <form action="{{ route('articulos.destroy', $art->id_articulo) }}"
                              method="POST" style="display:inline-block">
                            @csrf
                            @method('DELETE')
                            <button class="btn btn-danger">Eliminar</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>

    </table>

    {{-- Paginación --}}
    <div class="d-flex justify-content-center mt-3">
        {{ $articulos->links('pagination::bootstrap-4') }}
    </div>

</div>
@endsection
