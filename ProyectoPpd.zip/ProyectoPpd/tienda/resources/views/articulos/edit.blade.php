@extends('layouts.app')

@section('content')
<div class="container">

    <h2>Editar Artículo</h2>

    <a href="{{ route('articulos.index') }}" class="btn btn-secondary mb-3">Volver</a>

    <form action="{{ route('articulos.update', $articulo->id_articulo) }}" method="POST">
        @csrf
        @method('PUT')

        <div class="mb-3">
            <label class="form-label">Descripción:</label>
            <input type="text" name="descripcion"
                   class="form-control @error('descripcion') is-invalid @enderror"
                   value="{{ old('descripcion', $articulo->descripcion) }}">
            @error('descripcion')
                <span class="invalid-feedback">{{ $message }}</span>
            @enderror
        </div>

        <div class="mb-3">
            <label class="form-label">Precio de Venta:</label>
            <input type="number" name="precio_venta"
                   class="form-control @error('precio_venta') is-invalid @enderror"
                   value="{{ old('precio_venta', $articulo->precio_venta) }}">
            @error('precio_venta')
                <span class="invalid-feedback">{{ $message }}</span>
            @enderror
        </div>

        <div class="mb-3">
            <label class="form-label">Precio de Costo:</label>
            <input type="number" name="precio_costo"
                   class="form-control @error('precio_costo') is-invalid @enderror"
                   value="{{ old('precio_costo', $articulo->precio_costo) }}">
            @error('precio_costo')
                <span class="invalid-feedback">{{ $message }}</span>
            @enderror
        </div>

        <div class="mb-3">
            <label class="form-label">Stock:</label>
            <input type="number" name="stock"
                   class="form-control @error('stock') is-invalid @enderror"
                   value="{{ old('stock', $articulo->stock) }}">
            @error('stock')
                <span class="invalid-feedback">{{ $message }}</span>
            @enderror
        </div>

        <div class="mb-3">
            <label class="form-label">Tipo de Artículo:</label>
            <select name="cod_tipo_articulo"
                class="form-select @error('cod_tipo_articulo') is-invalid @enderror">

                @foreach($tipoArticulos as $tipo)
                    <option value="{{ $tipo->id_tipoarticulo }}"
                        {{ old('cod_tipo_articulo', $articulo->cod_tipo_articulo) == $tipo->id_tipoarticulo ? 'selected' : '' }}>
                        {{ $tipo->descripcion_articulo }}
                    </option>
                @endforeach
            </select>

            @error('cod_tipo_articulo')
                <span class="invalid-feedback">{{ $message }}</span>
            @enderror
        </div>

        <div class="mb-3">
            <label class="form-label">Proveedor:</label>
            <select name="cod_proveedor"
                class="form-select @error('cod_proveedor') is-invalid @enderror">

                @foreach($proveedores as $prov)
                    <option value="{{ $prov->No_documento }}"
                        {{ old('cod_proveedor', $articulo->cod_proveedor) == $prov->No_documento ? 'selected' : '' }}>
                        {{ $prov->Nombre_comercial }}
                    </option>
                @endforeach
            </select>

            @error('cod_proveedor')
                <span class="invalid-feedback">{{ $message }}</span>
            @enderror
        </div>

        <div class="mb-3">
            <label class="form-label">Fecha de ingreso:</label>
            <input type="text" name="fecha_ingreso"
                   class="form-control @error('fecha_ingreso') is-invalid @enderror"
                   value="{{ old('fecha_ingreso', $articulo->fecha_ingreso) }}">
            @error('fecha_ingreso')
                <span class="invalid-feedback">{{ $message }}</span>
            @enderror
        </div>

        <button class="btn btn-primary">Actualizar</button>
    </form>
</div>
@endsection
