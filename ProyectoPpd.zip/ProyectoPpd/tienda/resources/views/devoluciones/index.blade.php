@extends('layouts.app')

@section('content')
<h2>Devoluciones Registradas</h2>

<a href="{{ url()->previous() }}" class="btn btn-secondary mb-3">Volver</a>

<table class="table table-bordered">
    <thead class="table-dark">
        <tr>
            <th>Artículo</th>
            <th>Cantidad</th>
            <th>Motivo</th>
            <th>Fecha</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($devoluciones as $d)
        <tr>
            <td>{{ $d->articulo->descripcion }}</td>
            <td>{{ $d->cantidad }}</td>
            <td>{{ $d->Motivo }}</td>
            <td>{{ $d->Fecha_devolucion }}</td>
        </tr>
        @endforeach
    </tbody>
</table>
@endsection
