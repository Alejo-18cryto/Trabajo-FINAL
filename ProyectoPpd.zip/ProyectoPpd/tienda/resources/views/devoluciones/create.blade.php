@extends('layouts.app')

@section('content')
<h2>Registrar Devolución</h2>

<form action="{{ route('devoluciones.store') }}" method="POST">
    @csrf

    <input type="hidden" name="cod_detallefactura" value="{{ $detalle->id_detalle }}">
    <input type="hidden" name="cod_articulo" value="{{ $detalle->cod_articulo }}">

    <div class="mb-3">
        <label>Artículo</label>
        <input type="text" class="form-control" value="{{ $detalle->articulo->descripcion }}" readonly>
    </div>

    <div class="mb-3">
        <label>Cantidad comprada</label>
        <input type="number" class="form-control" value="{{ $detalle->cantidad }}" readonly>
    </div>

    <div class="mb-3">
        <label>Cantidad a devolver</label>
        <input type="number" name="cantidad" class="form-control" min="1" max="{{ $detalle->cantidad }}" required>
    </div>

    <div class="mb-3">
        <label>Motivo</label>
        <textarea name="Motivo" class="form-control" required></textarea>
    </div>

    <button class="btn btn-success">Registrar Devolución</button>
</form>
@endsection
