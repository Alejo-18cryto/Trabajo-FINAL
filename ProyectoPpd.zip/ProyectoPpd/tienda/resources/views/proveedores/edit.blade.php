@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Editar Proveedor</h2>

    <form action="{{ route('proveedores.update', $proveedore->No_documento) }}" method="POST">
        @csrf @method('PUT')

        <div class="row">
            <div class="col-md-4">
                <label>Documento</label>
                <input type="text" class="form-control" value="{{ $proveedore->No_documento }}" disabled>
            </div>

            <div class="col-md-4">
                <label>Tipo Documento</label>
                <select name="cod_tipo_documento" class="form-control" required>
                    @foreach($tipos as $t)
                        <option value="{{ $t->id_tipo_documento }}" 
                           {{ $t->id_tipo_documento == $proveedore->cod_tipo_documento ? 'selected' : '' }}>
                           {{ $t->Nombre }}
                        </option>
                    @endforeach
                </select>
            </div>

            <div class="col-md-4">
                <label>Ciudad</label>
                <select name="cod_ciudad" class="form-control" required>
                    @foreach($ciudades as $c)
                        <option value="{{ $c->Codigo_ciudad }}"
                            {{ $c->Codigo_ciudad == $proveedore->cod_ciudad ? 'selected' : '' }}>
                            {{ $c->Nombre_ciudad }}
                        </option>
                    @endforeach
                </select>
            </div>
        </div>

        <div class="row mt-2">
            <div class="col-md-6">
                <label>Nombre</label>
                <input type="text" name="Nombre" value="{{ $proveedore->Nombre }}" class="form-control" required>
            </div>

            <div class="col-md-6">
                <label>Apellido</label>
                <input type="text" name="Apellido" value="{{ $proveedore->Apellido }}" class="form-control" required>
            </div>
        </div>

        <div class="mt-2">
            <label>Nombre Comercial</label>
            <input type="text" name="Nombre_comercial" value="{{ $proveedore->Nombre_comercial }}" class="form-control" required>
        </div>

        <div class="mt-2">
            <label>Dirección</label>
            <input type="text" name="Direccion" value="{{ $proveedore->Direccion }}" class="form-control" required>
        </div>

        <div class="mt-2">
            <label>Teléfono</label>
            <input type="text" name="Telefono" value="{{ $proveedore->Telefono }}" class="form-control" required>
        </div>

        <button class="btn btn-success mt-3">Actualizar</button>
    </form>
</div>
@endsection
