@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Proveedores</h2>

    <form method="GET" class="mb-3">
        <input type="text" name="buscar" class="form-control" placeholder="Buscar proveedor..." value="{{ $busqueda }}">
    </form>

    <a href="{{ route('proveedores.create') }}" class="btn btn-primary mb-3">Nuevo Proveedor</a>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <table class="table table-striped">
        <thead>
            <tr>
                <th>Documento</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Nombre Comercial</th>
                <th>Teléfono</th>
                <th>Opciones</th>
            </tr>
        </thead>

        <tbody>
            @foreach($proveedores as $p)
            <tr>
                <td>{{ $p->No_documento }}</td>
                <td>{{ $p->Nombre }}</td>
                <td>{{ $p->Apellido }}</td>
                <td>{{ $p->Nombre_comercial }}</td>
                <td>{{ $p->Telefono }}</td>
                <td>
                    <a href="{{ route('proveedores.edit', $p->No_documento) }}" class="btn btn-warning btn-sm">Editar</a>

                    <form action="{{ route('proveedores.destroy', $p->No_documento) }}" method="POST" style="display:inline">
                        @csrf @method('DELETE')
                        <button class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar proveedor?')">Eliminar</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>

    {{ $proveedores->links() }}

</div>
@endsection
