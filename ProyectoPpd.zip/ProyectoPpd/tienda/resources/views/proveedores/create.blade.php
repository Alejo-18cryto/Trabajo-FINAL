@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Registrar Proveedor</h2>

    <form action="{{ route('proveedores.store') }}" method="POST">
        @csrf

        <div class="row">
            <div class="col-md-4">
                <label>Documento</label>
                <input type="text" name="No_documento" class="form-control" required>
            </div>

            <div class="col-md-4">
                <label>Tipo Documento</label>
                <select name="cod_tipo_documento" class="form-control" required>
                    <option value="">Seleccione</option>
                    @foreach($tipos as $t)
                        <option value="{{ $t->id_tipo_documento }}">{{ $t->Descripcion }}</option>
                    @endforeach
                </select>
            </div>

            <div class="col-md-4">
                <label>Ciudad</label>
                <select name="cod_ciudad" class="form-control" required>
                    @foreach($ciudades as $c)
                        <option value="{{ $c->Codigo_ciudad }}">{{ $c->Nombre_ciudad }}</option>
                    @endforeach
                </select>
            </div>
        </div>

        <div class="row mt-2">
            <div class="col-md-6">
                <label>Nombre</label>
                <input type="text" name="Nombre" class="form-control" required>
            </div>

            <div class="col-md-6">
                <label>Apellido</label>
                <input type="text" name="Apellido" class="form-control" required>
            </div>
        </div>

        <div class="mt-2">
            <label>Nombre Comercial</label>
            <input type="text" name="Nombre_comercial" class="form-control" required>
        </div>

        <div class="mt-2">
            <label>Dirección</label>
            <input type="text" name="Direccion" class="form-control" required>
        </div>

        <div class="mt-2">
            <label>Teléfono</label>
            <input type="text" name="Telefono" class="form-control" required>
        </div>

        <button class="btn btn-success mt-3">Guardar</button>
    </form>
</div>
@endsection
