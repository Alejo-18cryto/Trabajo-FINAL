@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Nueva Forma de Pago</h2>

    <form action="{{ route('formapago.store') }}" method="POST">
        @csrf

        <div class="mb-3">
            <label>Descripción</label>
            <input type="text" name="Descripcion_formapago" class="form-control" required>
        </div>

        <button class="btn btn-success">Guardar</button>
        <a href="{{ route('formapago.index') }}" class="btn btn-secondary">Cancelar</a>
    </form>
</div>
@endsection
