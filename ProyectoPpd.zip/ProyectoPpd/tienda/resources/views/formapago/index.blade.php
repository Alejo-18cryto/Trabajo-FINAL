@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Formas de Pago</h2>

    <a href="{{ route('formapago.create') }}" class="btn btn-primary mb-3">
        Nueva Forma de Pago
    </a>

    @if(session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Descripción</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
        @foreach($formas as $f)
            <tr>
                <td>{{ $f->id_formapago }}</td>
                <td>{{ $f->Descripcion_formapago }}</td>
                <td>
                    <a href="{{ route('formapago.edit', $f->id_formapago) }}" class="btn btn-warning btn-sm">Editar</a>

                    <form action="{{ route('formapago.destroy', $f->id_formapago) }}" method="POST" style="display:inline-block;">
                        @csrf
                        @method('DELETE')

                        <button class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar?')">
                            Eliminar
                        </button>
                    </form>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
@endsection
