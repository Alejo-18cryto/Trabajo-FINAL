@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Editar Forma de Pago</h2>

    <form action="{{ route('formapago.update', $forma->id_formapago) }}" method="POST">
        @csrf
        @method('PUT')

        <div class="mb-3">
            <label>Descripción</label>
            <input type="text" name="Descripcion_formapago" 
                   value="{{ $forma->Descripcion_formapago }}" 
                   class="form-control" required>
        </div>

        <button class="btn btn-success">Actualizar</button>
        <a href="{{ route('formapago.index') }}" class="btn btn-secondary">Cancelar</a>
    </form>
</div>
@endsection
