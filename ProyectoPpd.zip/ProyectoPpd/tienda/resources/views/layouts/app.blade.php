<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Facturación</title>

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
    <div class="container">
        <a class="navbar-brand" href="{{ url('/') }}">Sistema</a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="menu">
            <ul class="navbar-nav me-auto">

                <li class="nav-item">
                    <a class="nav-link {{ request()->routeIs('clientes.*') ? 'active' : '' }}"
                        href="{{ route('clientes.index') }}">
                        Clientes
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link {{ request()->routeIs('articulos.*') ? 'active' : '' }}"
                        href="{{ route('articulos.index') }}">
                        Artículos
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link {{ request()->routeIs('proveedores.*') ? 'active' : '' }}"
                        href="{{ route('proveedores.index') }}">
                        Proveedores
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link {{ request()->routeIs('facturas.*') ? 'active' : '' }}"
                        href="{{ route('facturas.index') }}">
                        Facturas
                    </a>
                </li>

                 <li class="nav-item">
                    <a class="nav-link {{ request()->routeIs('devoluciones.*') ? 'active' : '' }}"
                        href="{{ route('devoluciones.index') }}">
                        devoluciones
                    </a>
                </li>

                 <li class="nav-item">
                    <a class="nav-link {{ request()->routeIs('formapago.*') ? 'active' : '' }}"
                        href="{{ route('formapago.index') }}">
                        Forma de Pago
                    </a>
                </li>

                 <li class="nav-item">
                    <a class="nav-link {{ request()->routeIs('tipoarticulo.*') ? 'active' : '' }}"
                        href="{{ route('tipoarticulo.index') }}">
                       Tipo de Articulo
                    </a>
                </li>
            </ul>

        

            <span class="navbar-text text-white">
                @auth
                    {{ auth()->user()->name }}
                @else
                    Invitado
                @endauth
            </span>

        </div>
    </div>
</nav>

<div class="container">
    @yield('content')
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
